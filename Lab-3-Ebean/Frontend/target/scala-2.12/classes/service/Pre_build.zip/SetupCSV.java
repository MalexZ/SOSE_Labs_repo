package service;
import java.io.*;
import java.nio.file.Paths;
import java.util.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;


public class SetupCSV {
    public static void createCsv(List titles, List cat) {
        String fullPath = new File("").getAbsolutePath();
        fullPath = fullPath + "\\baseFile.csv";
        String[] finalTitle= new String[50];
        Integer[] totalEach= new Integer[50];
        System.out.println(fullPath);
        try {
            CSVWriter csvWriter = new CSVWriter(new FileWriter(fullPath));
            for(int i=0;i<50;i++){
                for(int j=0;j<titles.size();j++) {
                    if (cat.get(j).equals(i)) {
                        if (finalTitle[i]==null) {
                            finalTitle[i] = titles.get(j) + "||";
                            totalEach[i] = 1;
                        }
                        else {
                            finalTitle[i] += titles.get(j) + "||";
                            totalEach[i] += 1;
                        }
                    }
                }
            }
            int temp =0;
            for(int i=0;i<50;i++){
                String catNum= Integer.toString(i);
                //id, category, titles(delimiter="||"), total each
                temp = totalEach[i];
                csvWriter.writeNext(new String[]{catNum, finalTitle[i], Integer.toString(temp)});
            }
            csvWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static int findLargestCategory(List<Double> operate) {
        int category = 0;
        double largest = operate.stream().max(Comparator.naturalOrder()).get();

        for (int i = 0; i < operate.size(); i++) {
            if (operate.get(i) == largest) {
                category = i;
                break;
            }
        }


        return category;
    }

    public static String parseName(String title) {
        title = title.replaceAll("%20", " ");
        title = title.replaceAll("\\-\\+\\-", ":");
        title = title.replace("file:/C:/mallet/sample-data/abstract/", "");
        title = title.replace("..txt", "");

        System.out.println("parsing");
        return title;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fullPath = new File("").getAbsolutePath();
        fullPath = fullPath + "\\AbstractTest.csv";
        //File file= new File(fullPath);
        CSVReader reader = new CSVReader(new FileReader(fullPath));
        //Scanner sc = new Scanner(new File("AbstractTest.csv"));
        // System.out.println(fullPath);
        StringBuffer buffer = new StringBuffer();
        String line[];
        Iterator it = reader.iterator();
        /*
        while (it.hasNext()){
            line = (String[]) it.next();
            System.out.println(Arrays.toString(line));
            System.out.println(" ");
        }
        */


        int row = 0;

        //array for titles and probabilities
        List<String> titles = new ArrayList<String>();
        List<Integer> cat = new ArrayList<Integer>();
        List<Double> operate = new ArrayList<Double>();
        int largestCategory;
        String name;
        while (it.hasNext())
        {
            System.out.println("in while");
            line = (String[]) it.next();


            if (row != 0) {

                name = line[1];
                name = parseName(name);
                titles.add(name);

                for (int i = 2; i < 52; i++)
                    operate.add(Double.parseDouble(line[i]));


                largestCategory = findLargestCategory(operate);
                cat.add(largestCategory);
            }
            operate.clear();
            row++;
        }
        createCsv(titles, cat);
    }


}



